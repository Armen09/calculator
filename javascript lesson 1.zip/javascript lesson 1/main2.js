let str = "bAreR";
let str2 =  str.toUpperCase();
str2 = str2.split("");
for(let i = 1;i <str2.length;i++) {
str2[i] = str[i].toLowerCase(); 
}
console.log(str2);